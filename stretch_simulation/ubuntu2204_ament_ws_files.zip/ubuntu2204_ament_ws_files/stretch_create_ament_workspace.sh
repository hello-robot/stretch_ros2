. /etc/hello-robot/hello-robot.conf
echo "###########################################"
echo "NEW INSTALLATION OF USER SOFTWARE"
echo "###########################################"
echo "Update ~/.bashrc dotfile..."
echo "" >> ~/.bashrc
echo "######################" >> ~/.bashrc
echo "# STRETCH BASHRC SETUP" >> ~/.bashrc
echo "######################" >> ~/.bashrc
echo "export HELLO_FLEET_PATH=${HOME}/stretch_user" >> ~/.bashrc
echo "export HELLO_FLEET_ID=${HELLO_FLEET_ID}">> ~/.bashrc
echo "export PATH=\${PATH}:~/.local/bin" >> ~/.bashrc
echo "export LRS_LOG_LEVEL=None #Debug" >> ~/.bashrc
echo "export PYTHONWARNINGS='ignore:setup.py install is deprecated,ignore:Invalid dash-separated options,ignore:pkg_resources is deprecated as an API,ignore:Usage of dash-separated'" >> ~/.bashrc

echo "export _colcon_cd_root=${HOME}/ament_ws" >> ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc


echo "Creating repos and stretch_user directories..."
mkdir -p ~/.local/bin
mkdir -p ~/repos
mkdir -p ~/stretch_user
mkdir -p ~/stretch_user/log
mkdir -p ~/stretch_user/debug
mkdir -p ~/stretch_user/maps
mkdir -p ~/stretch_user/models



echo "Setting up user copy of robot factory data (if not already there)..."

sudo cp -rf /etc/hello-robot/$HELLO_FLEET_ID $HOME/stretch_user
sudo chown -R $USER:$USER $HOME/stretch_user/$HELLO_FLEET_ID
chmod a-w $HOME/stretch_user/$HELLO_FLEET_ID/udev/*.rules

chmod -R a-x,o-w,+X ~/stretch_user

sudo add-apt-repository ppa:sweptlaser/python3-pcl
sudo apt update
sudo apt install python3-pcl


export PATH=${PATH}:~/.local/bin
export HELLO_FLEET_ID=$HELLO_FLEET_ID
export HELLO_FLEET_PATH=${HOME}/stretch_user

echo "Ensuring correct version of params present..."
params_dir_path=$HELLO_FLEET_PATH/$HELLO_FLEET_ID
echo "Checking params directory path: $params_dir_path"

# Define file paths based on the provided directory
user_params="$params_dir_path/stretch_re1_user_params.yaml"
factory_params="$params_dir_path/stretch_re1_factory_params.yaml"
new_config_params="$params_dir_path/stretch_configuration_params.yaml"
new_user_params="$params_dir_path/stretch_user_params.yaml"

~/stretch_install/factory/22.04/stretch_create_ament_workspace.sh -w "$HOME/ament_ws"


echo "###########################################"
echo "INSTALLATION OF USER LEVEL PIP3 PACKAGES"
echo "###########################################"
echo "Clear pip cache"
python3 -m pip cache purge
echo "Upgrade pip3"
python3 -m pip -q install --no-warn-script-location --user --upgrade pip
echo "Install Stretch Body"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-body
echo "Install Stretch Body Tools"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-body-tools
echo "Install Stretch Factory"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-factory
echo "Install Stretch Tool Share"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-tool-share
echo "Install Stretch Diagnostics"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-diagnostics
echo "Install Stretch URDF"
python3 -m pip -q install --no-warn-script-location --upgrade hello-robot-stretch-urdf
echo "Upgrade prompt_toolkit"
python3 -m pip -q install --no-warn-script-location -U prompt_toolkit
echo "Remove setuptools-scm"
python3 -m pip -q uninstall -y setuptools-scm
echo ""
