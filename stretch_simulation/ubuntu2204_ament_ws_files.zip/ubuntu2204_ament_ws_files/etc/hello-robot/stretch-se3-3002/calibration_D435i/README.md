Robot specific data here.

